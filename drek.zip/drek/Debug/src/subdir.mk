################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
LD_SRCS += \
../src/lscript.ld 

C_SRCS += \
../src/main.c \
../src/motorMoveFunc.c \
../src/platform.c \
../src/pwmFunc.c \
../src/scu_timer.c \
../src/sensors.c \
../src/timer_f.c \
../src/xadc.c 

OBJS += \
./src/main.o \
./src/motorMoveFunc.o \
./src/platform.o \
./src/pwmFunc.o \
./src/scu_timer.o \
./src/sensors.o \
./src/timer_f.o \
./src/xadc.o 

C_DEPS += \
./src/main.d \
./src/motorMoveFunc.d \
./src/platform.d \
./src/pwmFunc.d \
./src/scu_timer.d \
./src/sensors.d \
./src/timer_f.d \
./src/xadc.d 


# Each subdirectory must supply rules for building sources it contributes
src/%.o: ../src/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: ARM v7 gcc compiler'
	arm-none-eabi-gcc -Wall -O0 -g3 -c -fmessage-length=0 -MT"$@" -mcpu=cortex-a9 -mfpu=vfpv3 -mfloat-abi=hard -IC:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


