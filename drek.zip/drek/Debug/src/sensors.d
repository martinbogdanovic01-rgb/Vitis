src/sensors.o src/sensors.o: ../src/sensors.c ../src/sensors.h \
 ../src/xadc.h \
 C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xadcps.h \
 C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xil_types.h \
 C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xparameters.h \
 C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xparameters_ps.h \
 C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xil_assert.h \
 C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xstatus.h \
 C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xadcps_hw.h \
 C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xil_io.h \
 C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xil_printf.h \
 C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/bspconfig.h \
 C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xpseudo_asm.h \
 C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xreg_cortexa9.h \
 C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xpseudo_asm_gcc.h \
 ../src/motorMoveFunc.h ../src/config.h \
 C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xparameters.h
../src/sensors.h:
../src/xadc.h:
C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xadcps.h:
C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xil_types.h:
C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xparameters.h:
C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xparameters_ps.h:
C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xil_assert.h:
C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xstatus.h:
C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xadcps_hw.h:
C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xil_io.h:
C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xil_printf.h:
C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/bspconfig.h:
C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xpseudo_asm.h:
C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xreg_cortexa9.h:
C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xpseudo_asm_gcc.h:
../src/motorMoveFunc.h:
../src/config.h:
C:/Users/marti/workspace/system_wrapper/export/system_wrapper/sw/system_wrapper/standalone_ps7_cortexa9_0/bspinclude/include/xparameters.h:
