#ifndef MOTORMOVEFUNC_H
#define MOTORMOVEFUNC_H

typedef enum {
    MOVE_NONE,
    MOVE_POSITIVE_MED,
    MOVE_NEGATIVE_MED
} MotorDirection;

void moveHorMotor(MotorDirection dir);
void moveVerMotor(MotorDirection dir);

#endif
