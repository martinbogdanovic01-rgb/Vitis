#ifndef PWMFUNC_H
#define PWMFUNC_H

#include "xtmrctr.h"
#include "config.h"

#define PWM_DUTY_40_PERCENT ((PWM_PERIOD * 40) / 100)
#define PWM_DUTY_50_PERCENT ((PWM_PERIOD * 50) / 100)
#define PWM_DUTY_60_PERCENT ((PWM_PERIOD * 60) / 100)

extern XTmrCtr TimerHor;
extern XTmrCtr TimerVer;

void Init_pwm();

#endif
