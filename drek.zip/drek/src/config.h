#ifndef CONFIG_H
#define CONFIG_H

#include "xparameters.h"

#define PWM_PERIOD 100000
#define MOVE_DEADZONE_TH 0.12  // Adjusted to be slightly higher than your 0.098 gap

// ... other defines ...

// CHANGE THESE TWO LINES:
#define AR6 1  // Pin 6 is Bit Index 1 in the GPIO bank
#define AR7 2  // Pin 7 is Bit Index 2 in the GPIO bank

// Also ensure these IDs match your friend's working setup:
#define GPIO_DEVICE_ID  XPAR_ARDUINO_ARDUINO_NO_INTR_PINS_DEVICE_ID
#define TMR0_DEVICE_ID  XPAR_TMRCTR_0_DEVICE_ID
#define TMR1_DEVICE_ID  XPAR_TMRCTR_1_DEVICE_ID

// ... rest of file ...

#endif
