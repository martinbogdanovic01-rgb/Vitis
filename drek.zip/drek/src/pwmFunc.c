#include "pwmFunc.h"
#include "timer_f.h"
#include "config.h"

XTmrCtr TimerHor;
XTmrCtr TimerVer;

void Init_pwm() {
    PwmInit(&TimerHor, 0);
    PwmInit(&TimerVer, 1);
    XTmrCtr_PwmDisable(&TimerHor);
    PwmConfig(&TimerVer, PWM_PERIOD, PWM_DUTY_50_PERCENT);
}
