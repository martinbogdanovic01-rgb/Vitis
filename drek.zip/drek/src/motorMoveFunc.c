#include "motorMoveFunc.h"
#include "pwmFunc.h"
#include "config.h"
#include "xgpio.h"
#include "timer_f.h"

extern XGpio outputGPIO;

void moveHorMotor(MotorDirection dir) {
    uint32_t current = XGpio_DiscreteRead(&outputGPIO, 1);

    if (dir == MOVE_POSITIVE_MED) {
        current |= (1 << AR6); current &= ~(1 << AR7);
        XGpio_DiscreteWrite(&outputGPIO, 1, current);
        PwmConfig(&TimerHor, PWM_PERIOD, PWM_DUTY_50_PERCENT);
    } else if (dir == MOVE_NEGATIVE_MED) {
        current |= (1 << AR7); current &= ~(1 << AR6);
        XGpio_DiscreteWrite(&outputGPIO, 1, current);
        PwmConfig(&TimerHor, PWM_PERIOD, PWM_DUTY_50_PERCENT);
    } else {
        current &= ~((1 << AR6) | (1 << AR7));
        XGpio_DiscreteWrite(&outputGPIO, 1, current);
        XTmrCtr_PwmDisable(&TimerHor);
    }
}

void moveVerMotor(MotorDirection dir) {
    if (dir == MOVE_POSITIVE_MED)      PwmConfig(&TimerVer, PWM_PERIOD, PWM_DUTY_60_PERCENT);
    else if (dir == MOVE_NEGATIVE_MED) PwmConfig(&TimerVer, PWM_PERIOD, PWM_DUTY_40_PERCENT);
    else                               PwmConfig(&TimerVer, PWM_PERIOD, PWM_DUTY_50_PERCENT);
}
