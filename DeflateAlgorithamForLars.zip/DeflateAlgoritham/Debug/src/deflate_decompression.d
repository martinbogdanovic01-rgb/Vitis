src/deflate_decompression.o src/deflate_decompression.o: \
 ../src/deflate_decompression.c ../src/deflate.h
../src/deflate.h:
