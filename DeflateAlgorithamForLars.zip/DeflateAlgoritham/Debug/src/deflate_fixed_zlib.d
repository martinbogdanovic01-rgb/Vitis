src/deflate_fixed_zlib.o src/deflate_fixed_zlib.o: \
 ../src/deflate_fixed_zlib.c
