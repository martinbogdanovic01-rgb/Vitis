src/deflate_compression.o src/deflate_compression.o: \
 ../src/deflate_compression.c ../src/deflate_compression.h \
 ../src/deflate.h
../src/deflate_compression.h:
../src/deflate.h:
